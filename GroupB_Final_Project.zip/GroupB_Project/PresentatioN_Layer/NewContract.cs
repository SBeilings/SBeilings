﻿using GroupB_Project.PresentatioN_Layer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GroupB_Project
{
    public partial class NewContract : Form
    {
        public NewContract()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
            ContractMaintenanceAgentDashboard curr_menu = new ContractMaintenanceAgentDashboard();
            curr_menu.Show();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                System.Random random = new System.Random();
                txtPackageID.Text = random.Next(0, 999900000).ToString();
                string packageID = txtPackageID.Text;
                string Name = txtName.Text;
                string serviceLevel = cmbServiceLevel.Text;
                string contractType = cmbContractType.Text;
                string serviceType = cmbServiceType.Text;
                string startDate = dtpStartDate.Text;
                string endDate = dtpEndate.Text;

                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";

                if (packageID != "")
                {
                    if (Name != "")
                    {
                        if (serviceLevel != "")
                        {
                            if (contractType != "")
                            {
                                if (serviceType != "")
                                {
                                    if (startDate != "")
                                    {
                                        if (endDate != "")
                                        {
                                            conn.Open();
                                            SqlCommand cmdInsert = new SqlCommand("Insert into CONTRACTS(PACKAGE_ID , NAME, SERVICE_LEVEL, CONTRACT_TYPE, SERVICE_TYPE, START_DATE, END_DATE) VALUES ('" + packageID + "', '" + Name + "', '" + serviceLevel + "', '" + contractType + "', '" + serviceType + "', '" + startDate + "', '" + endDate + "')", conn);
                                            int insertedRows = cmdInsert.ExecuteNonQuery();

                                            MessageBox.Show("Added Successfully!", "Action Completed Successfully!");
                                        }
                                        else
                                        {
                                            MessageBox.Show("End Date cannot be blank!");
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Start Date cannot be blank!");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Service Type cannot be blank!");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Contract Type cannot be blank!");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Service Level cannot be blank!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Name cannot be blank!");
                    }
                }
                else
                {
                    MessageBox.Show("Package ID cannot be blank!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void NewContract_Load(object sender, EventArgs e)
        {
            string[] contractType = { "Adhoc", "Fixed" };
            string[] serviceLevel = { "Customer", "Internal", "Multi-Level" };
            string[] serviceType = { "In-House", "Outsourced" };

            cmbContractType.Items.AddRange(contractType);
            cmbServiceLevel.Items.AddRange(serviceLevel);
            cmbServiceType.Items.AddRange(serviceType);
        }
    }
}
