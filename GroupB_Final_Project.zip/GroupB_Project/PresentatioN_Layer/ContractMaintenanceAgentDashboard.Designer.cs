﻿
namespace GroupB_Project.PresentatioN_Layer
{
    partial class ContractMaintenanceAgentDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbxViewContract = new System.Windows.Forms.GroupBox();
            this.lblContractNumber = new System.Windows.Forms.Label();
            this.btnViewAll = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.dgvViewContracts = new System.Windows.Forms.DataGridView();
            this.btnCreateNewContract = new System.Windows.Forms.Button();
            this.gbxUpdatePackage = new System.Windows.Forms.GroupBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.txtPackageID = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.dtpEndate = new System.Windows.Forms.DateTimePicker();
            this.dtpStartDate = new System.Windows.Forms.DateTimePicker();
            this.cmbServiceType = new System.Windows.Forms.ComboBox();
            this.cmbContractType = new System.Windows.Forms.ComboBox();
            this.cmbServiceLevel = new System.Windows.Forms.ComboBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnLogout = new System.Windows.Forms.Button();
            this.gbxViewContract.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvViewContracts)).BeginInit();
            this.gbxUpdatePackage.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbxViewContract
            // 
            this.gbxViewContract.Controls.Add(this.lblContractNumber);
            this.gbxViewContract.Controls.Add(this.btnViewAll);
            this.gbxViewContract.Controls.Add(this.btnSearch);
            this.gbxViewContract.Controls.Add(this.txtSearch);
            this.gbxViewContract.Controls.Add(this.dgvViewContracts);
            this.gbxViewContract.Location = new System.Drawing.Point(12, 27);
            this.gbxViewContract.Name = "gbxViewContract";
            this.gbxViewContract.Size = new System.Drawing.Size(795, 561);
            this.gbxViewContract.TabIndex = 5;
            this.gbxViewContract.TabStop = false;
            this.gbxViewContract.Text = "View and Create Contract";
            // 
            // lblContractNumber
            // 
            this.lblContractNumber.AutoSize = true;
            this.lblContractNumber.Location = new System.Drawing.Point(464, 30);
            this.lblContractNumber.Name = "lblContractNumber";
            this.lblContractNumber.Size = new System.Drawing.Size(64, 13);
            this.lblContractNumber.TabIndex = 12;
            this.lblContractNumber.Text = "Package ID";
            // 
            // btnViewAll
            // 
            this.btnViewAll.Location = new System.Drawing.Point(371, 490);
            this.btnViewAll.Margin = new System.Windows.Forms.Padding(2);
            this.btnViewAll.Name = "btnViewAll";
            this.btnViewAll.Size = new System.Drawing.Size(94, 28);
            this.btnViewAll.TabIndex = 9;
            this.btnViewAll.Text = "Refresh";
            this.btnViewAll.UseVisualStyleBackColor = true;
            this.btnViewAll.Click += new System.EventHandler(this.btnViewAll_Click_1);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(712, 26);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(2);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(69, 20);
            this.btnSearch.TabIndex = 8;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(554, 26);
            this.txtSearch.Margin = new System.Windows.Forms.Padding(2);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(140, 20);
            this.txtSearch.TabIndex = 6;
            // 
            // dgvViewContracts
            // 
            this.dgvViewContracts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvViewContracts.Location = new System.Drawing.Point(15, 67);
            this.dgvViewContracts.Margin = new System.Windows.Forms.Padding(2);
            this.dgvViewContracts.Name = "dgvViewContracts";
            this.dgvViewContracts.RowHeadersWidth = 51;
            this.dgvViewContracts.RowTemplate.Height = 24;
            this.dgvViewContracts.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvViewContracts.Size = new System.Drawing.Size(766, 407);
            this.dgvViewContracts.TabIndex = 5;
            this.dgvViewContracts.SelectionChanged += new System.EventHandler(this.dgvViewContracts_SelectionChanged);
            // 
            // btnCreateNewContract
            // 
            this.btnCreateNewContract.Location = new System.Drawing.Point(334, 606);
            this.btnCreateNewContract.Margin = new System.Windows.Forms.Padding(2);
            this.btnCreateNewContract.Name = "btnCreateNewContract";
            this.btnCreateNewContract.Size = new System.Drawing.Size(198, 57);
            this.btnCreateNewContract.TabIndex = 7;
            this.btnCreateNewContract.Text = "Create New Contract";
            this.btnCreateNewContract.UseVisualStyleBackColor = true;
            this.btnCreateNewContract.Click += new System.EventHandler(this.btnCreateNewContract_Click);
            // 
            // gbxUpdatePackage
            // 
            this.gbxUpdatePackage.Controls.Add(this.btnDelete);
            this.gbxUpdatePackage.Controls.Add(this.txtPackageID);
            this.gbxUpdatePackage.Controls.Add(this.txtName);
            this.gbxUpdatePackage.Controls.Add(this.dtpEndate);
            this.gbxUpdatePackage.Controls.Add(this.dtpStartDate);
            this.gbxUpdatePackage.Controls.Add(this.cmbServiceType);
            this.gbxUpdatePackage.Controls.Add(this.cmbContractType);
            this.gbxUpdatePackage.Controls.Add(this.cmbServiceLevel);
            this.gbxUpdatePackage.Controls.Add(this.btnSave);
            this.gbxUpdatePackage.Controls.Add(this.label7);
            this.gbxUpdatePackage.Controls.Add(this.label6);
            this.gbxUpdatePackage.Controls.Add(this.label5);
            this.gbxUpdatePackage.Controls.Add(this.label4);
            this.gbxUpdatePackage.Controls.Add(this.label3);
            this.gbxUpdatePackage.Controls.Add(this.label2);
            this.gbxUpdatePackage.Controls.Add(this.label1);
            this.gbxUpdatePackage.Location = new System.Drawing.Point(838, 39);
            this.gbxUpdatePackage.Name = "gbxUpdatePackage";
            this.gbxUpdatePackage.Size = new System.Drawing.Size(383, 409);
            this.gbxUpdatePackage.TabIndex = 6;
            this.gbxUpdatePackage.TabStop = false;
            this.gbxUpdatePackage.Text = "Update Contract";
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(65, 351);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(78, 24);
            this.btnDelete.TabIndex = 33;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // txtPackageID
            // 
            this.txtPackageID.Location = new System.Drawing.Point(175, 34);
            this.txtPackageID.Margin = new System.Windows.Forms.Padding(2);
            this.txtPackageID.Name = "txtPackageID";
            this.txtPackageID.ReadOnly = true;
            this.txtPackageID.Size = new System.Drawing.Size(131, 20);
            this.txtPackageID.TabIndex = 32;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(175, 71);
            this.txtName.Margin = new System.Windows.Forms.Padding(2);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(131, 20);
            this.txtName.TabIndex = 31;
            // 
            // dtpEndate
            // 
            this.dtpEndate.Location = new System.Drawing.Point(175, 295);
            this.dtpEndate.Margin = new System.Windows.Forms.Padding(2);
            this.dtpEndate.Name = "dtpEndate";
            this.dtpEndate.Size = new System.Drawing.Size(131, 20);
            this.dtpEndate.TabIndex = 30;
            // 
            // dtpStartDate
            // 
            this.dtpStartDate.Location = new System.Drawing.Point(175, 253);
            this.dtpStartDate.Margin = new System.Windows.Forms.Padding(2);
            this.dtpStartDate.Name = "dtpStartDate";
            this.dtpStartDate.Size = new System.Drawing.Size(131, 20);
            this.dtpStartDate.TabIndex = 29;
            // 
            // cmbServiceType
            // 
            this.cmbServiceType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbServiceType.FormattingEnabled = true;
            this.cmbServiceType.Location = new System.Drawing.Point(175, 207);
            this.cmbServiceType.Margin = new System.Windows.Forms.Padding(2);
            this.cmbServiceType.Name = "cmbServiceType";
            this.cmbServiceType.Size = new System.Drawing.Size(131, 21);
            this.cmbServiceType.TabIndex = 28;
            // 
            // cmbContractType
            // 
            this.cmbContractType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbContractType.FormattingEnabled = true;
            this.cmbContractType.Location = new System.Drawing.Point(175, 162);
            this.cmbContractType.Margin = new System.Windows.Forms.Padding(2);
            this.cmbContractType.Name = "cmbContractType";
            this.cmbContractType.Size = new System.Drawing.Size(131, 21);
            this.cmbContractType.TabIndex = 27;
            this.cmbContractType.MouseClick += new System.Windows.Forms.MouseEventHandler(this.cmbContractType_MouseClick);
            // 
            // cmbServiceLevel
            // 
            this.cmbServiceLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbServiceLevel.FormattingEnabled = true;
            this.cmbServiceLevel.Location = new System.Drawing.Point(175, 120);
            this.cmbServiceLevel.Margin = new System.Windows.Forms.Padding(2);
            this.cmbServiceLevel.Name = "cmbServiceLevel";
            this.cmbServiceLevel.Size = new System.Drawing.Size(131, 21);
            this.cmbServiceLevel.TabIndex = 26;
            this.cmbServiceLevel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.cmbServiceLevel_MouseClick);
            // 
            // btnSave
            // 
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(266, 349);
            this.btnSave.Margin = new System.Windows.Forms.Padding(2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(80, 26);
            this.btnSave.TabIndex = 24;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(66, 120);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 13);
            this.label7.TabIndex = 23;
            this.label7.Text = "Service Level:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(66, 164);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 13);
            this.label6.TabIndex = 22;
            this.label6.Text = "Contract Type:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(66, 207);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "Service Type:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(66, 253);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 13);
            this.label4.TabIndex = 20;
            this.label4.Text = "Start Date:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(66, 300);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "End Date:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(66, 76);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "Name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(66, 34);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "Package ID:";
            // 
            // btnLogout
            // 
            this.btnLogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.Location = new System.Drawing.Point(999, 549);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(2);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(185, 70);
            this.btnLogout.TabIndex = 25;
            this.btnLogout.Text = "Home";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // ContractMaintenanceAgentDashboard
            // 
            this.AccessibleName = "ContractMaintenanceAgentDashboard";
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1314, 685);
            this.Controls.Add(this.gbxUpdatePackage);
            this.Controls.Add(this.gbxViewContract);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnCreateNewContract);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ContractMaintenanceAgentDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Contract Maintenance - Agent Dashboard";
            this.Load += new System.EventHandler(this.ContractMaintenanceAgentDashboard_Load);
            this.gbxViewContract.ResumeLayout(false);
            this.gbxViewContract.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvViewContracts)).EndInit();
            this.gbxUpdatePackage.ResumeLayout(false);
            this.gbxUpdatePackage.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbxViewContract;
        private System.Windows.Forms.Button btnViewAll;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnCreateNewContract;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.DataGridView dgvViewContracts;
        private System.Windows.Forms.Label lblContractNumber;
        private System.Windows.Forms.GroupBox gbxUpdatePackage;
        private System.Windows.Forms.TextBox txtPackageID;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.DateTimePicker dtpEndate;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
        private System.Windows.Forms.ComboBox cmbServiceType;
        private System.Windows.Forms.ComboBox cmbContractType;
        private System.Windows.Forms.ComboBox cmbServiceLevel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnDelete;
    }
}