﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GroupB_Project.PresentatioN_Layer
{
    public partial class CallCentreAgentDashboard : Form
    {
        public CallCentreAgentDashboard()
        {
            InitializeComponent();
        }

        private void btnCreateNewIncident_Click(object sender, EventArgs e)
        {
            this.Close();
            frmNewIncident curr_menu = new frmNewIncident();
            curr_menu.Show();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Login GetName = new Login();
            string uname = GetName.getUserName();
            if (uname.Substring(0, 3) == "SER")
            {
                this.Close();
                frmServiceMaintenanceAgentDashboard curr_menu = new frmServiceMaintenanceAgentDashboard();
                curr_menu.Show();
            }
            else
            {
                this.Close();
                Login curr_menu = new Login();
                curr_menu.Show();
            }
        }

        private void btnCreateNewIncident_Click_1(object sender, EventArgs e)
        {
            this.Close();
            frmNewIncident curr_menu = new frmNewIncident();
            curr_menu.Show();
        }

        private void CallCentreAgentDashboard_Load(object sender, EventArgs e)
        {
            string[] incidentType = { "Installation", "Maintenance", "Repair" };
            cmbIncidentType.Items.AddRange(incidentType);

            string[] technicianNames = { "Marcel", "Lesego", "Koketso", "Shamiel", "Andre" , "Luffy" };
            cmbTechnician.Items.AddRange(technicianNames);

            var slcquery = "SELECT * FROM dbo.INCIDENTS";
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";
            conn.Open();
            var dataAdapter = new SqlDataAdapter(slcquery, conn);
            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            conn.Close();
            dgvViewTickets.ReadOnly = true;
            dgvViewTickets.DataSource = ds.Tables[0];
        }

        private void btnViewAll_Click(object sender, EventArgs e)
        {
            var slcquery = "SELECT * FROM dbo.INCIDENTS";
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";
            conn.Open();
            var dataAdapter = new SqlDataAdapter(slcquery, conn);
            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            conn.Close();
            dgvViewTickets.ReadOnly = true;
            dgvViewTickets.DataSource = ds.Tables[0];
        }

        private void dgvViewTickets_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                foreach (DataGridViewRow row in dgvViewTickets.SelectedRows)
                {

                    txtIncidentNo.Text = row.Cells[0].Value.ToString();
                    cmbIncidentType.Text = row.Cells[1].Value.ToString();
                    cmbClientID.Text = row.Cells[2].Value.ToString();
                    txtWorkRequestNo.Text = row.Cells[3].Value.ToString();
                    txtStatus.Text = row.Cells[4].Value.ToString();
                    cmbTechnician.Text = row.Cells[5].Value.ToString();

                }

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string incidentNumber = txtIncidentNo.Text;
                string incidentType = cmbIncidentType.Text;
                string clientID = cmbClientID.Text;
                string workRequest = txtWorkRequestNo.Text;
                string status = txtStatus.Text;
                string technician = cmbTechnician.Text;

                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";

                if (incidentNumber != "")
                {
                    if (incidentType != "")
                    {
                        if (clientID != "")
                        {
                            if (workRequest != "")
                            {
                                if (status != "")
                                {
                                    if (technician != "")
                                    {
                                        conn.Open();
                                        SqlCommand cmdUpdate = new SqlCommand("Update dbo.INCIDENTS SET INCIDENT_TYPE = '" + incidentType + "', CLIENT_ID = '" + clientID + "', WORK_REQ_NUMBER = '"
                                            + workRequest + "', STATUS = '" + status + "', TECHNICIAN = '" + technician + "' WHERE INCIDENT_NUM = '" + incidentNumber + "'", conn);
                                        int updatedRows = cmdUpdate.ExecuteNonQuery();

                                        var slcquery = "SELECT * FROM dbo.INCIDENTS";
                                        var dataAdapter = new SqlDataAdapter(slcquery, conn);
                                        var commandBuilder = new SqlCommandBuilder(dataAdapter);
                                        var ds = new DataSet();
                                        dataAdapter.Fill(ds);
                                        conn.Close();
                                        dgvViewTickets.ReadOnly = true;
                                        dgvViewTickets.DataSource = ds.Tables[0];

                                        MessageBox.Show("Updated Successfully!", "Action Completed Successfully!");

                                    }
                                    else
                                    {
                                        MessageBox.Show("Technician cannot be blank!");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Status cannot be blank!");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Work Request cannot be blank!");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Client ID cannot be blank!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Incident Tyoe cannot be blank!");
                    }
                }
                else
                {
                    MessageBox.Show("Incident Number cannot be blank!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                string incidentNumber = txtIncidentNo.Text;
                string incidentType = cmbIncidentType.Text;
                string clientID = cmbClientID.Text;
                string workRequest = txtWorkRequestNo.Text;
                string status = txtStatus.Text;
                string technician = cmbTechnician.Text;

                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";

                if (incidentNumber != "")
                {
                    if (incidentType != "")
                    {
                        if (clientID != "")
                        {
                            if (workRequest != "")
                            {
                                if (status != "")
                                {
                                    if (technician != "")
                                    {
                                        conn.Open();
                                        SqlCommand cmdDelete= new SqlCommand("DELETE FROM dbo.INCIDENTS WHERE INCIDENT_NUM = '" + incidentNumber + "'", conn);
                                        int updatedRows = cmdDelete.ExecuteNonQuery();

                                        var slcquery = "SELECT * FROM dbo.INCIDENTS";
                                        var dataAdapter = new SqlDataAdapter(slcquery, conn);
                                        var commandBuilder = new SqlCommandBuilder(dataAdapter);
                                        var ds = new DataSet();
                                        dataAdapter.Fill(ds);
                                        conn.Close();
                                        dgvViewTickets.ReadOnly = true;
                                        dgvViewTickets.DataSource = ds.Tables[0];

                                        MessageBox.Show("Updated Successfully!", "Action Completed Successfully!");

                                    }
                                    else
                                    {
                                        MessageBox.Show("Technician cannot be blank!");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Status cannot be blank!");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Work Request cannot be blank!");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Client ID cannot be blank!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Incident Tyoe cannot be blank!");
                    }
                }
                else
                {
                    MessageBox.Show("Incident Number cannot be blank!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmbIncidentType_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void cmbIncidentType_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void gbxViewIncidents_Enter(object sender, EventArgs e)
        {

        }

        private void cmbClientID_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbClientID_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void dgvViewTickets_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnSearch_Click_1(object sender, EventArgs e)
        {
            string incidentNumber = txtIncidentNum.Text;
            if (incidentNumber!="")
            {
                var slcquery = "SELECT * FROM dbo.INCIDENTS WHERE INCIDENT_NUM LIKE '%" + incidentNumber +"%'";
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";
                conn.Open();
                var dataAdapter = new SqlDataAdapter(slcquery, conn);
                var commandBuilder = new SqlCommandBuilder(dataAdapter);
                var ds = new DataSet();
                dataAdapter.Fill(ds);
                conn.Close();
                dgvViewTickets.ReadOnly = true;
                dgvViewTickets.DataSource = ds.Tables[0];
            }
            else
            {
                var slcquery = "SELECT * FROM dbo.INCIDENTS";
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";
                conn.Open();
                var dataAdapter = new SqlDataAdapter(slcquery, conn);
                var commandBuilder = new SqlCommandBuilder(dataAdapter);
                var ds = new DataSet();
                dataAdapter.Fill(ds);
                conn.Close();
                dgvViewTickets.ReadOnly = true;
                dgvViewTickets.DataSource = ds.Tables[0];
            }
        }
    }
}
