﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GroupB_Project.Data_Layer;
using GroupB_Project.PresentatioN_Layer;
using System.Data.SqlClient;

namespace GroupB_Project

{
    public partial class NewClient : Form
    {
        public NewClient()
        {
            InitializeComponent();
        }
        DataHandler handler = new DataHandler();    

        private void btnSave_Click(object sender, EventArgs e)
        {
            //int client = ToString(txtClientID.Text);
            try
            {
                string clientID = txtClientID.Text;
                string name = txtName.Text;
                string lname = txtLName.Text;
                string contact = txtContact.Text;
                string status = cmbStatus.Text;
                string address = txtAddress.Text;
                string type = cmbType.Text;
                string Packagetype = cmbPacakge.Text;
                string notes = rtbNotes.Text;
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";

                if (clientID != "")
                {
                    if (name != "")
                    {
                        if (lname != "")
                        {
                            if (contact != "")
                            {
                                if (status != "")
                                {
                                    if (address != "")
                                    {
                                        if (type != "")
                                        {
                                            if (Packagetype != "")
                                            {
                                               
                                                conn.Open();
                                                SqlCommand cmdInsert = new SqlCommand("Insert into CLIENTS(CLIENT_ID , FNAME, SNAME, CONTACTNUMBER, ADDRESS, STATUS, TYPE, PACKAGE_TYPE, NOTES) VALUES ('" + clientID + "', '" + name + "', '" + lname + "', '" + contact + "', '" + address + "', '" + status + "', '" + type + "', '" + Packagetype + "', '" + notes + "')", conn);
                                                int insertedRows = cmdInsert.ExecuteNonQuery();
                                                conn.Close();
                                                MessageBox.Show("Details Entered into System","Successfully Added Client Details!");
                                            }
                                            else
                                            {
                                                MessageBox.Show("Package Type is blank!");
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show("Type is blank!");
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Address is blank!");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Status is blank!");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Contact is blank!");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Last Name is blank!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("First Name is blank!");
                    }
                }
                else
                {
                    MessageBox.Show("Client ID is blank!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void cmbType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbStatus_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void NewClient_Load(object sender, EventArgs e)
        {
            string[] PackageList = { "Free(Limited Features)", "Premium(Advanced Features)", "Pro(All Features)" };
            string[] clientType = { "Individual Client", "Business Client" };
            string[] status = { "Paid", "Payment Outstanding", "Cancelled" };

            cmbStatus.Items.AddRange(status);
            cmbPacakge.Items.AddRange(PackageList);
            cmbType.Items.AddRange(clientType);
        }

        private void txtContact_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtClientID_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmbPacakge_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void rtbNotes_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
            ClientMaintenaceAgentDashboard curr_menu = new ClientMaintenaceAgentDashboard();
            curr_menu.Show();
        }

    }
}
