﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GroupB_Project.PresentatioN_Layer;
using System.Data.SqlClient;

namespace GroupB_Project
{
    public partial class frmNewIncident : Form
    {
        public frmNewIncident()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
            CallCentreAgentDashboard curr_menu = new CallCentreAgentDashboard();
            curr_menu.Show();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string incidentNumber = txtIncidentNo.Text;
                string incidentType = cmbIncidentType.Text;
                string clientID = cmbClientID.Text;
                string workRequest = txtWorkRequestNo.Text;
                string status = txtStatus.Text;
                string technician = cmbTechnician.Text;

                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";

                if (incidentNumber != "")
                {
                    if (incidentType != "")
                    {
                        if (clientID != "")
                        {
                            if (workRequest != "")
                            {
                                if (status != "")
                                {
                                    if (technician != "")
                                    {
                                        conn.Open();
                                        SqlCommand cmdInsert = new SqlCommand("INSERT INTO dbo.INCIDENTS(INCIDENT_NUM, INCIDENT_TYPE, CLIENT_ID, WORK_REQ_NUMBER, STATUS, TECHNICIAN) VALUES('" + incidentNumber + "','" + incidentType + "','" + clientID + "','" + workRequest + "','" + status + "', '" + technician + "')", conn);
                                        int insertedRows = cmdInsert.ExecuteNonQuery();
                                        conn.Close();
                                        MessageBox.Show("Details Entered into System", "Successfully Added Client Details!");
                                    }
                                    else
                                    {
                                        MessageBox.Show("Technician cannot be blank!");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Status cannot be blank!");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Work Request cannot be blank!");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Client ID cannot be blank!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Incident Tyoe cannot be blank!");
                    }
                }
                else
                {
                    MessageBox.Show("Incident Number cannot be blank!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void frmNewIncident_Load(object sender, EventArgs e)
        {
            string[] incidentType = { "Installation", "Maintenance", "Repair" };
            cmbIncidentType.Items.AddRange(incidentType);

            string[] technicianNames = { "Marcel", "Lesego", "Koketso", "Shamiel", "Andre", "Luffy" };
            cmbTechnician.Items.AddRange(technicianNames);
        }

        private void linkLSearchClient_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ClientIDSearch pop_up = new ClientIDSearch();
            pop_up.ShowDialog();
        }

        private void cmbClientID_MouseClick(object sender, MouseEventArgs e)
        {

        }
    }
}
