﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GroupB_Project.PresentatioN_Layer
{
    public partial class ContractMaintenanceAgentDashboard : Form
    {
        public ContractMaintenanceAgentDashboard()
        {
            InitializeComponent();
        }

        private void btnViewAll_Click(object sender, EventArgs e)
        {

        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Login GetName = new Login();
            string uname = GetName.getUserName();
            if (uname.Substring(0, 3) == "SER")
            {
                this.Close();
                frmServiceMaintenanceAgentDashboard curr_menu = new frmServiceMaintenanceAgentDashboard();
                curr_menu.Show();
            }
            else
            {
                this.Close();
                Login curr_menu = new Login();
                curr_menu.Show();
            }
        }

        private void btnCreateNewContract_Click(object sender, EventArgs e)
        {
            this.Close();
            NewContract curr_menu = new NewContract();
            curr_menu.Show();
        }

        private void ContractMaintenanceAgentDashboard_Load(object sender, EventArgs e)
        {
            string[] contractType = { "Adhoc", "Fixed" };
            string[] serviceLevel = { "Customer", "Internal", "Multi-Level" };
            string[] serviceType = { "In-House", "Outsourced" };

            cmbContractType.Items.AddRange(contractType);
            cmbServiceLevel.Items.AddRange(serviceLevel);
            cmbServiceType.Items.AddRange(serviceType);

            var slcquery = "SELECT * FROM dbo.CONTRACTS";
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";
            conn.Open();
            var dataAdapter = new SqlDataAdapter(slcquery, conn);
            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            conn.Close();
            dgvViewContracts.ReadOnly = true;
            dgvViewContracts.DataSource = ds.Tables[0];
        }

        private void btnViewAll_Click_1(object sender, EventArgs e)
        {
            var slcquery = "SELECT * FROM dbo.CONTRACTS";
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";
            conn.Open();
            var dataAdapter = new SqlDataAdapter(slcquery, conn);
            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            conn.Close();
            dgvViewContracts.ReadOnly = true;
            dgvViewContracts.DataSource = ds.Tables[0];
        }

        private void dgvViewContracts_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                foreach (DataGridViewRow row in dgvViewContracts.SelectedRows)
                {

                    txtPackageID.Text = row.Cells[0].Value.ToString();
                    txtName.Text = row.Cells[1].Value.ToString();
                    cmbServiceLevel.Text = row.Cells[2].Value.ToString();
                    cmbContractType.Text = row.Cells[3].Value.ToString();
                    cmbServiceType.Text = row.Cells[4].Value.ToString();
                    dtpStartDate.Text = row.Cells[5].Value.ToString();
                    dtpEndate.Text = row.Cells[6].Value.ToString();
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string packageID = txtPackageID.Text;
                string Name = txtName.Text;
                string serviceLevel = cmbServiceLevel.Text;
                string contractType = cmbContractType.Text;
                string serviceType = cmbServiceType.Text;
                string startDate = dtpStartDate.Text;
                string endDate = dtpEndate.Text;
                
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";

                if (packageID != "")
                {
                    if (Name != "")
                    {
                        if (serviceLevel != "")
                        {
                            if (contractType != "")
                            {
                                if (serviceType!= "")
                                {
                                    if (startDate != "")
                                    {
                                        if (endDate != "")
                                        {
                                                conn.Open();
                                                SqlCommand cmdUpdate = new SqlCommand("Update dbo.CONTRACTS SET NAME = '" + Name + "', SERVICE_LEVEL = '" + serviceLevel + "', CONTRACT_TYPE = '"
                                                    + contractType + "', SERVICE_TYPE = '" + serviceType + "', START_DATE = '" + startDate + "', END_DATE = '" + endDate + "' WHERE PACKAGE_ID = '" + packageID + "'", conn);
                                                int updatedRows = cmdUpdate.ExecuteNonQuery();

                                                var slcquery = "SELECT * FROM dbo.CONTRACTS";
                                                var dataAdapter = new SqlDataAdapter(slcquery, conn);
                                                var commandBuilder = new SqlCommandBuilder(dataAdapter);
                                                var ds = new DataSet();
                                                dataAdapter.Fill(ds);
                                                conn.Close();
                                                dgvViewContracts.ReadOnly = true;
                                                dgvViewContracts.DataSource = ds.Tables[0];

                                                MessageBox.Show("Updated Successfully!", "Action Completed Successfully!");
                                                                                    }
                                        else
                                        {
                                            MessageBox.Show("End Date cannot be blank!");
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Start Date cannot be blank!");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Service Type cannot be blank!");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Contract Type cannot be blank!");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Service Level cannot be blank!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Name cannot be blank!");
                    }
                }
                else
                {
                    MessageBox.Show("Package ID cannot be blank!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                string packageID = txtPackageID.Text;
                string Name = txtName.Text;
                string serviceLevel = cmbServiceLevel.Text;
                string contractType = cmbContractType.Text;
                string serviceType = cmbServiceType.Text;
                string startDate = dtpStartDate.Text;
                string endDate = dtpEndate.Text;

                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";

                if (packageID != "")
                {
                    if (Name != "")
                    {
                        if (serviceLevel != "")
                        {
                            if (contractType != "")
                            {
                                if (serviceType != "")
                                {
                                    if (startDate != "")
                                    {
                                        if (endDate != "")
                                        {
                                            conn.Open();
                                            SqlCommand cmdDelete = new SqlCommand("DELETE FROM dbo.CONTRACTS WHERE PACKAGE_ID = '" + packageID + "'", conn);
                                            int updatedRows = cmdDelete.ExecuteNonQuery();

                                            var slcquery = "SELECT * FROM dbo.CONTRACTS";
                                            var dataAdapter = new SqlDataAdapter(slcquery, conn);
                                            var commandBuilder = new SqlCommandBuilder(dataAdapter);
                                            var ds = new DataSet();
                                            dataAdapter.Fill(ds);
                                            conn.Close();
                                            dgvViewContracts.ReadOnly = true;
                                            dgvViewContracts.DataSource = ds.Tables[0];

                                            MessageBox.Show("Updated Successfully!", "Action Completed Successfully!");
                                        }
                                        else
                                        {
                                            MessageBox.Show("End Date cannot be blank!");
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Start Date cannot be blank!");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Service Type cannot be blank!");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Contract Type cannot be blank!");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Service Level cannot be blank!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Name cannot be blank!");
                    }
                }
                else
                {
                    MessageBox.Show("Package ID cannot be blank!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmbServiceLevel_MouseClick(object sender, MouseEventArgs e)
        { 
            //cmbServiceLevel.Items.Add("","");
        }

        private void cmbContractType_MouseClick(object sender, MouseEventArgs e)
        {
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string clientNum = txtSearch.Text;
            if (clientNum != "")
            {
                var slcquery = "SELECT * FROM dbo.CONTRACTS WHERE PACKAGE_ID LIKE '%" + clientNum + "%'";
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";
                conn.Open();
                var dataAdapter = new SqlDataAdapter(slcquery, conn);
                var commandBuilder = new SqlCommandBuilder(dataAdapter);
                var ds = new DataSet();
                dataAdapter.Fill(ds);
                conn.Close();
                dgvViewContracts.ReadOnly = true;
                dgvViewContracts.DataSource = ds.Tables[0];
            }
            else
            {
                var slcquery = "SELECT * FROM dbo.CLIENTS";
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";
                conn.Open();
                var dataAdapter = new SqlDataAdapter(slcquery, conn);
                var commandBuilder = new SqlCommandBuilder(dataAdapter);
                var ds = new DataSet();
                dataAdapter.Fill(ds);
                conn.Close();
                dgvViewContracts.ReadOnly = true;
                dgvViewContracts.DataSource = ds.Tables[0];
            }
        }
    }
    
}

