﻿
namespace GroupB_Project
{
    partial class frmNewIncident
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblIncidentNo = new System.Windows.Forms.Label();
            this.txtIncidentNo = new System.Windows.Forms.TextBox();
            this.lblncidentType = new System.Windows.Forms.Label();
            this.lblTechnician = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblWorkRequest = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbIncidentType = new System.Windows.Forms.ComboBox();
            this.txtWorkRequestNo = new System.Windows.Forms.TextBox();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.cmbTechnician = new System.Windows.Forms.ComboBox();
            this.linkLSearchClient = new System.Windows.Forms.LinkLabel();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.cmbClientID = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lblIncidentNo
            // 
            this.lblIncidentNo.AutoSize = true;
            this.lblIncidentNo.Location = new System.Drawing.Point(40, 32);
            this.lblIncidentNo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblIncidentNo.Name = "lblIncidentNo";
            this.lblIncidentNo.Size = new System.Drawing.Size(88, 13);
            this.lblIncidentNo.TabIndex = 0;
            this.lblIncidentNo.Text = "Incident Number:";
            // 
            // txtIncidentNo
            // 
            this.txtIncidentNo.Location = new System.Drawing.Point(172, 32);
            this.txtIncidentNo.Margin = new System.Windows.Forms.Padding(2);
            this.txtIncidentNo.Name = "txtIncidentNo";
            this.txtIncidentNo.Size = new System.Drawing.Size(120, 20);
            this.txtIncidentNo.TabIndex = 15;
            // 
            // lblncidentType
            // 
            this.lblncidentType.AutoSize = true;
            this.lblncidentType.Location = new System.Drawing.Point(40, 73);
            this.lblncidentType.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblncidentType.Name = "lblncidentType";
            this.lblncidentType.Size = new System.Drawing.Size(75, 13);
            this.lblncidentType.TabIndex = 16;
            this.lblncidentType.Text = "Incident Type:";
            // 
            // lblTechnician
            // 
            this.lblTechnician.AutoSize = true;
            this.lblTechnician.Location = new System.Drawing.Point(42, 258);
            this.lblTechnician.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTechnician.Name = "lblTechnician";
            this.lblTechnician.Size = new System.Drawing.Size(63, 13);
            this.lblTechnician.TabIndex = 17;
            this.lblTechnician.Text = "Technician:";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(42, 210);
            this.lblStatus.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(40, 13);
            this.lblStatus.TabIndex = 18;
            this.lblStatus.Text = "Status:";
            // 
            // lblWorkRequest
            // 
            this.lblWorkRequest.AutoSize = true;
            this.lblWorkRequest.Location = new System.Drawing.Point(42, 162);
            this.lblWorkRequest.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblWorkRequest.Name = "lblWorkRequest";
            this.lblWorkRequest.Size = new System.Drawing.Size(117, 13);
            this.lblWorkRequest.TabIndex = 19;
            this.lblWorkRequest.Text = "Work Request number:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(40, 118);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 13);
            this.label6.TabIndex = 20;
            this.label6.Text = "Client ID:";
            // 
            // cmbIncidentType
            // 
            this.cmbIncidentType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbIncidentType.FormattingEnabled = true;
            this.cmbIncidentType.Location = new System.Drawing.Point(172, 73);
            this.cmbIncidentType.Margin = new System.Windows.Forms.Padding(2);
            this.cmbIncidentType.Name = "cmbIncidentType";
            this.cmbIncidentType.Size = new System.Drawing.Size(120, 21);
            this.cmbIncidentType.TabIndex = 21;
            // 
            // txtWorkRequestNo
            // 
            this.txtWorkRequestNo.Location = new System.Drawing.Point(172, 158);
            this.txtWorkRequestNo.Margin = new System.Windows.Forms.Padding(2);
            this.txtWorkRequestNo.Name = "txtWorkRequestNo";
            this.txtWorkRequestNo.Size = new System.Drawing.Size(120, 20);
            this.txtWorkRequestNo.TabIndex = 23;
            // 
            // txtStatus
            // 
            this.txtStatus.Location = new System.Drawing.Point(172, 206);
            this.txtStatus.Margin = new System.Windows.Forms.Padding(2);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(120, 20);
            this.txtStatus.TabIndex = 24;
            // 
            // cmbTechnician
            // 
            this.cmbTechnician.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTechnician.FormattingEnabled = true;
            this.cmbTechnician.Location = new System.Drawing.Point(172, 250);
            this.cmbTechnician.Margin = new System.Windows.Forms.Padding(2);
            this.cmbTechnician.Name = "cmbTechnician";
            this.cmbTechnician.Size = new System.Drawing.Size(120, 21);
            this.cmbTechnician.TabIndex = 25;
            // 
            // linkLSearchClient
            // 
            this.linkLSearchClient.AutoSize = true;
            this.linkLSearchClient.Location = new System.Drawing.Point(337, 117);
            this.linkLSearchClient.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.linkLSearchClient.Name = "linkLSearchClient";
            this.linkLSearchClient.Size = new System.Drawing.Size(84, 13);
            this.linkLSearchClient.TabIndex = 26;
            this.linkLSearchClient.TabStop = true;
            this.linkLSearchClient.Text = "Search Client ID";
            this.linkLSearchClient.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLSearchClient_LinkClicked);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(188, 302);
            this.btnSave.Margin = new System.Windows.Forms.Padding(2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(77, 26);
            this.btnSave.TabIndex = 27;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(383, 322);
            this.btnClose.Margin = new System.Windows.Forms.Padding(2);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(77, 26);
            this.btnClose.TabIndex = 28;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // cmbClientID
            // 
            this.cmbClientID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbClientID.FormattingEnabled = true;
            this.cmbClientID.Location = new System.Drawing.Point(172, 115);
            this.cmbClientID.Margin = new System.Windows.Forms.Padding(2);
            this.cmbClientID.Name = "cmbClientID";
            this.cmbClientID.Size = new System.Drawing.Size(120, 21);
            this.cmbClientID.TabIndex = 29;
            this.cmbClientID.MouseClick += new System.Windows.Forms.MouseEventHandler(this.cmbClientID_MouseClick);
            // 
            // frmNewIncident
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(495, 372);
            this.Controls.Add(this.cmbClientID);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.linkLSearchClient);
            this.Controls.Add(this.cmbTechnician);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.txtWorkRequestNo);
            this.Controls.Add(this.cmbIncidentType);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblWorkRequest);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lblTechnician);
            this.Controls.Add(this.lblncidentType);
            this.Controls.Add(this.txtIncidentNo);
            this.Controls.Add(this.lblIncidentNo);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmNewIncident";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "New Incident";
            this.Load += new System.EventHandler(this.frmNewIncident_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblIncidentNo;
        private System.Windows.Forms.TextBox txtIncidentNo;
        private System.Windows.Forms.Label lblncidentType;
        private System.Windows.Forms.Label lblTechnician;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblWorkRequest;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbIncidentType;
        private System.Windows.Forms.TextBox txtWorkRequestNo;
        private System.Windows.Forms.TextBox txtStatus;
        private System.Windows.Forms.ComboBox cmbTechnician;
        private System.Windows.Forms.LinkLabel linkLSearchClient;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ComboBox cmbClientID;
    }
}