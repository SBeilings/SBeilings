﻿
namespace GroupB_Project.PresentatioN_Layer
{
    partial class CallCentreAgentDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbxViewIncidents = new System.Windows.Forms.GroupBox();
            this.lblIncidentNum = new System.Windows.Forms.Label();
            this.txtIncidentNum = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnViewAll = new System.Windows.Forms.Button();
            this.btnCreateNewIncident = new System.Windows.Forms.Button();
            this.dgvViewTickets = new System.Windows.Forms.DataGridView();
            this.gbxUpdateIncidents = new System.Windows.Forms.GroupBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.cmbTechnician = new System.Windows.Forms.ComboBox();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.txtWorkRequestNo = new System.Windows.Forms.TextBox();
            this.cmbIncidentType = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.lblWorkRequest = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblTechnician = new System.Windows.Forms.Label();
            this.lblncidentType = new System.Windows.Forms.Label();
            this.txtIncidentNo = new System.Windows.Forms.TextBox();
            this.lblIncidentNo = new System.Windows.Forms.Label();
            this.btnLogout = new System.Windows.Forms.Button();
            this.cmbClientID = new System.Windows.Forms.ComboBox();
            this.gbxViewIncidents.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvViewTickets)).BeginInit();
            this.gbxUpdateIncidents.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbxViewIncidents
            // 
            this.gbxViewIncidents.Controls.Add(this.lblIncidentNum);
            this.gbxViewIncidents.Controls.Add(this.txtIncidentNum);
            this.gbxViewIncidents.Controls.Add(this.btnSearch);
            this.gbxViewIncidents.Controls.Add(this.btnViewAll);
            this.gbxViewIncidents.Controls.Add(this.btnCreateNewIncident);
            this.gbxViewIncidents.Controls.Add(this.dgvViewTickets);
            this.gbxViewIncidents.Location = new System.Drawing.Point(13, 12);
            this.gbxViewIncidents.Name = "gbxViewIncidents";
            this.gbxViewIncidents.Size = new System.Drawing.Size(849, 563);
            this.gbxViewIncidents.TabIndex = 6;
            this.gbxViewIncidents.TabStop = false;
            this.gbxViewIncidents.Text = "View And Create New Incidents";
            this.gbxViewIncidents.Enter += new System.EventHandler(this.gbxViewIncidents_Enter);
            // 
            // lblIncidentNum
            // 
            this.lblIncidentNum.AutoSize = true;
            this.lblIncidentNum.Location = new System.Drawing.Point(506, 31);
            this.lblIncidentNum.Name = "lblIncidentNum";
            this.lblIncidentNum.Size = new System.Drawing.Size(85, 13);
            this.lblIncidentNum.TabIndex = 11;
            this.lblIncidentNum.Text = "Incident Number";
            // 
            // txtIncidentNum
            // 
            this.txtIncidentNum.Location = new System.Drawing.Point(596, 27);
            this.txtIncidentNum.Margin = new System.Windows.Forms.Padding(2);
            this.txtIncidentNum.Name = "txtIncidentNum";
            this.txtIncidentNum.Size = new System.Drawing.Size(143, 20);
            this.txtIncidentNum.TabIndex = 10;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(743, 28);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(2);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(56, 19);
            this.btnSearch.TabIndex = 9;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click_1);
            // 
            // btnViewAll
            // 
            this.btnViewAll.Location = new System.Drawing.Point(379, 484);
            this.btnViewAll.Margin = new System.Windows.Forms.Padding(2);
            this.btnViewAll.Name = "btnViewAll";
            this.btnViewAll.Size = new System.Drawing.Size(56, 19);
            this.btnViewAll.TabIndex = 8;
            this.btnViewAll.Text = "Refresh";
            this.btnViewAll.UseVisualStyleBackColor = true;
            this.btnViewAll.Click += new System.EventHandler(this.btnViewAll_Click);
            // 
            // btnCreateNewIncident
            // 
            this.btnCreateNewIncident.Location = new System.Drawing.Point(351, 525);
            this.btnCreateNewIncident.Margin = new System.Windows.Forms.Padding(2);
            this.btnCreateNewIncident.Name = "btnCreateNewIncident";
            this.btnCreateNewIncident.Size = new System.Drawing.Size(122, 19);
            this.btnCreateNewIncident.TabIndex = 7;
            this.btnCreateNewIncident.Text = "Create New Incident";
            this.btnCreateNewIncident.UseVisualStyleBackColor = true;
            this.btnCreateNewIncident.Click += new System.EventHandler(this.btnCreateNewIncident_Click_1);
            // 
            // dgvViewTickets
            // 
            this.dgvViewTickets.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvViewTickets.Location = new System.Drawing.Point(33, 67);
            this.dgvViewTickets.Margin = new System.Windows.Forms.Padding(2);
            this.dgvViewTickets.Name = "dgvViewTickets";
            this.dgvViewTickets.RowHeadersWidth = 51;
            this.dgvViewTickets.RowTemplate.Height = 24;
            this.dgvViewTickets.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvViewTickets.Size = new System.Drawing.Size(766, 397);
            this.dgvViewTickets.TabIndex = 6;
            this.dgvViewTickets.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvViewTickets_CellContentClick);
            this.dgvViewTickets.SelectionChanged += new System.EventHandler(this.dgvViewTickets_SelectionChanged);
            // 
            // gbxUpdateIncidents
            // 
            this.gbxUpdateIncidents.Controls.Add(this.cmbClientID);
            this.gbxUpdateIncidents.Controls.Add(this.btnDelete);
            this.gbxUpdateIncidents.Controls.Add(this.btnSave);
            this.gbxUpdateIncidents.Controls.Add(this.cmbTechnician);
            this.gbxUpdateIncidents.Controls.Add(this.txtStatus);
            this.gbxUpdateIncidents.Controls.Add(this.txtWorkRequestNo);
            this.gbxUpdateIncidents.Controls.Add(this.cmbIncidentType);
            this.gbxUpdateIncidents.Controls.Add(this.label6);
            this.gbxUpdateIncidents.Controls.Add(this.lblWorkRequest);
            this.gbxUpdateIncidents.Controls.Add(this.lblStatus);
            this.gbxUpdateIncidents.Controls.Add(this.lblTechnician);
            this.gbxUpdateIncidents.Controls.Add(this.lblncidentType);
            this.gbxUpdateIncidents.Controls.Add(this.txtIncidentNo);
            this.gbxUpdateIncidents.Controls.Add(this.lblIncidentNo);
            this.gbxUpdateIncidents.Location = new System.Drawing.Point(889, 21);
            this.gbxUpdateIncidents.Name = "gbxUpdateIncidents";
            this.gbxUpdateIncidents.Size = new System.Drawing.Size(322, 386);
            this.gbxUpdateIncidents.TabIndex = 7;
            this.gbxUpdateIncidents.TabStop = false;
            this.gbxUpdateIncidents.Text = "Update Incident";
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(22, 339);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(78, 24);
            this.btnDelete.TabIndex = 43;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(188, 339);
            this.btnSave.Margin = new System.Windows.Forms.Padding(2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(81, 26);
            this.btnSave.TabIndex = 42;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // cmbTechnician
            // 
            this.cmbTechnician.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTechnician.FormattingEnabled = true;
            this.cmbTechnician.Location = new System.Drawing.Point(149, 276);
            this.cmbTechnician.Margin = new System.Windows.Forms.Padding(2);
            this.cmbTechnician.Name = "cmbTechnician";
            this.cmbTechnician.Size = new System.Drawing.Size(120, 21);
            this.cmbTechnician.TabIndex = 40;
            // 
            // txtStatus
            // 
            this.txtStatus.Location = new System.Drawing.Point(149, 232);
            this.txtStatus.Margin = new System.Windows.Forms.Padding(2);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(120, 20);
            this.txtStatus.TabIndex = 39;
            // 
            // txtWorkRequestNo
            // 
            this.txtWorkRequestNo.Location = new System.Drawing.Point(149, 184);
            this.txtWorkRequestNo.Margin = new System.Windows.Forms.Padding(2);
            this.txtWorkRequestNo.Name = "txtWorkRequestNo";
            this.txtWorkRequestNo.Size = new System.Drawing.Size(120, 20);
            this.txtWorkRequestNo.TabIndex = 38;
            // 
            // cmbIncidentType
            // 
            this.cmbIncidentType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbIncidentType.FormattingEnabled = true;
            this.cmbIncidentType.Location = new System.Drawing.Point(149, 99);
            this.cmbIncidentType.Margin = new System.Windows.Forms.Padding(2);
            this.cmbIncidentType.Name = "cmbIncidentType";
            this.cmbIncidentType.Size = new System.Drawing.Size(120, 21);
            this.cmbIncidentType.TabIndex = 36;
            this.cmbIncidentType.SelectedIndexChanged += new System.EventHandler(this.cmbIncidentType_SelectedIndexChanged);
            this.cmbIncidentType.MouseClick += new System.Windows.Forms.MouseEventHandler(this.cmbIncidentType_MouseClick);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 144);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 13);
            this.label6.TabIndex = 35;
            this.label6.Text = "Client ID:";
            // 
            // lblWorkRequest
            // 
            this.lblWorkRequest.AutoSize = true;
            this.lblWorkRequest.Location = new System.Drawing.Point(19, 188);
            this.lblWorkRequest.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblWorkRequest.Name = "lblWorkRequest";
            this.lblWorkRequest.Size = new System.Drawing.Size(117, 13);
            this.lblWorkRequest.TabIndex = 34;
            this.lblWorkRequest.Text = "Work Request number:";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(19, 236);
            this.lblStatus.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(40, 13);
            this.lblStatus.TabIndex = 33;
            this.lblStatus.Text = "Status:";
            // 
            // lblTechnician
            // 
            this.lblTechnician.AutoSize = true;
            this.lblTechnician.Location = new System.Drawing.Point(19, 284);
            this.lblTechnician.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTechnician.Name = "lblTechnician";
            this.lblTechnician.Size = new System.Drawing.Size(63, 13);
            this.lblTechnician.TabIndex = 32;
            this.lblTechnician.Text = "Technician:";
            // 
            // lblncidentType
            // 
            this.lblncidentType.AutoSize = true;
            this.lblncidentType.Location = new System.Drawing.Point(17, 99);
            this.lblncidentType.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblncidentType.Name = "lblncidentType";
            this.lblncidentType.Size = new System.Drawing.Size(75, 13);
            this.lblncidentType.TabIndex = 31;
            this.lblncidentType.Text = "Incident Type:";
            // 
            // txtIncidentNo
            // 
            this.txtIncidentNo.Location = new System.Drawing.Point(149, 58);
            this.txtIncidentNo.Margin = new System.Windows.Forms.Padding(2);
            this.txtIncidentNo.Name = "txtIncidentNo";
            this.txtIncidentNo.ReadOnly = true;
            this.txtIncidentNo.Size = new System.Drawing.Size(120, 20);
            this.txtIncidentNo.TabIndex = 30;
            // 
            // lblIncidentNo
            // 
            this.lblIncidentNo.AutoSize = true;
            this.lblIncidentNo.Location = new System.Drawing.Point(17, 58);
            this.lblIncidentNo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblIncidentNo.Name = "lblIncidentNo";
            this.lblIncidentNo.Size = new System.Drawing.Size(88, 13);
            this.lblIncidentNo.TabIndex = 29;
            this.lblIncidentNo.Text = "Incident Number:";
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(982, 481);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(2);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(140, 48);
            this.btnLogout.TabIndex = 43;
            this.btnLogout.Text = "Home";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // cmbClientID
            // 
            this.cmbClientID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbClientID.FormattingEnabled = true;
            this.cmbClientID.Location = new System.Drawing.Point(149, 144);
            this.cmbClientID.Margin = new System.Windows.Forms.Padding(2);
            this.cmbClientID.Name = "cmbClientID";
            this.cmbClientID.Size = new System.Drawing.Size(120, 21);
            this.cmbClientID.TabIndex = 44;
            this.cmbClientID.SelectedIndexChanged += new System.EventHandler(this.cmbClientID_SelectedIndexChanged);
            this.cmbClientID.MouseClick += new System.Windows.Forms.MouseEventHandler(this.cmbClientID_MouseClick);
            // 
            // CallCentreAgentDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1241, 587);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.gbxUpdateIncidents);
            this.Controls.Add(this.gbxViewIncidents);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "CallCentreAgentDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Call Centre - Agent Dashboard";
            this.Load += new System.EventHandler(this.CallCentreAgentDashboard_Load);
            this.gbxViewIncidents.ResumeLayout(false);
            this.gbxViewIncidents.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvViewTickets)).EndInit();
            this.gbxUpdateIncidents.ResumeLayout(false);
            this.gbxUpdateIncidents.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbxViewIncidents;
        private System.Windows.Forms.Label lblIncidentNum;
        private System.Windows.Forms.TextBox txtIncidentNum;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnViewAll;
        private System.Windows.Forms.Button btnCreateNewIncident;
        private System.Windows.Forms.DataGridView dgvViewTickets;
        private System.Windows.Forms.GroupBox gbxUpdateIncidents;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.ComboBox cmbTechnician;
        private System.Windows.Forms.TextBox txtStatus;
        private System.Windows.Forms.TextBox txtWorkRequestNo;
        private System.Windows.Forms.ComboBox cmbIncidentType;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblWorkRequest;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblTechnician;
        private System.Windows.Forms.Label lblncidentType;
        private System.Windows.Forms.TextBox txtIncidentNo;
        private System.Windows.Forms.Label lblIncidentNo;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.ComboBox cmbClientID;
    }
}