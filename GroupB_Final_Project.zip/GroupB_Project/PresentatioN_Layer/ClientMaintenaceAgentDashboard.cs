﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GroupB_Project.PresentatioN_Layer
{
    public partial class ClientMaintenaceAgentDashboard : Form
    {
        public ClientMaintenaceAgentDashboard()
        {
            InitializeComponent();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Login GetName = new Login();
            string uname = GetName.getUserName();
            if (uname.Substring(0, 3) == "SER")
            {
                this.Close();
                frmServiceMaintenanceAgentDashboard curr_menu = new frmServiceMaintenanceAgentDashboard();
                curr_menu.Show();
            }
            else
            {
                this.Close();
                Login curr_menu = new Login();
                curr_menu.Show();
            }
        }

        private void btnCreateNewClient_Click(object sender, EventArgs e)
        {
            this.Close();
            NewClient curr_menu = new NewClient();
            curr_menu.Show();
        }

        private void ClientMaintenaceAgentDashboard_Load(object sender, EventArgs e)
        {
            string[] PackageList = { "Free(Limited Features)","Premium(Advanced Features)","Pro(All Features)"};
            string[] clientType = { "Individual Client", "Business Client" };
            string[] status = { "Paid","Payment Outstanding", "Cancelled"};

            cmbStatus.Items.AddRange(status);
            cmbPacakge.Items.AddRange(PackageList);
            cmbType.Items.AddRange(clientType);

            var slcquery = "SELECT * FROM dbo.CLIENTS";
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";
            conn.Open();
            var dataAdapter = new SqlDataAdapter(slcquery, conn);
            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            conn.Close();
            dgvViewClient.ReadOnly = true;
            dgvViewClient.DataSource = ds.Tables[0];

        }

        private void gbxViewClients_Enter(object sender, EventArgs e)
        {

        }

        private void btnViewAll_Click(object sender, EventArgs e)
        {
            var slcquery = "SELECT * FROM dbo.CLIENTS";
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";
            conn.Open();
            var dataAdapter = new SqlDataAdapter(slcquery, conn);
            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            conn.Close();
            dgvViewClient.ReadOnly = true;
            dgvViewClient.DataSource = ds.Tables[0];
        }

        private void dgvViewClient_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                foreach (DataGridViewRow row in dgvViewClient.SelectedRows)
                {

                    txtClientID.Text = row.Cells[0].Value.ToString();
                    txtName.Text = row.Cells[1].Value.ToString();
                    txtLName.Text = row.Cells[2].Value.ToString();
                    txtContact.Text = row.Cells[3].Value.ToString();
                    txtAddress.Text = row.Cells[4].Value.ToString();
                    cmbStatus.Text = row.Cells[5].Value.ToString();
                    cmbType.Text = row.Cells[6].Value.ToString();
                    cmbPacakge.Text = row.Cells[7].Value.ToString();
                    rtbNotes.Text = row.Cells[8].Value.ToString();

                }

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void dgvViewClient_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string clientID = txtClientID.Text;
                string firstName = txtName.Text;
                string lastName = txtLName.Text;
                string contactNumber = txtContact.Text;
                string address = txtAddress.Text;
                string status = cmbStatus.Text;
                string type = cmbType.Text;
                string packageType = cmbPacakge.Text;
                string notes = rtbNotes.Text;

                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";

                if (clientID != "")
                {
                    if (firstName != "")
                    {
                        if (lastName != "")
                        {
                            if (contactNumber != "")
                            {
                                if (address != "")
                                {
                                    if (status != "")
                                    {
                                        if (type != "")
                                        {
                                            if (packageType != "")
                                            {
                                                conn.Open();
                                                SqlCommand cmdUpdate = new SqlCommand("Update dbo.CLIENTS SET FNAME = '" + firstName + "', SNAME = '" + lastName + "', CONTACTNUMBER = '" 
                                                    + contactNumber + "', ADDRESS = '" + address + "', STATUS = '" + status + "', TYPE = '" + type + "', PACKAGE_TYPE = '" + packageType + "', NOTES = '" 
                                                    + notes + "' WHERE CLIENT_ID = '" + clientID + "'", conn);
                                                int updatedRows = cmdUpdate.ExecuteNonQuery();

                                                var slcquery = "SELECT * FROM dbo.CLIENTS";
                                                var dataAdapter = new SqlDataAdapter(slcquery, conn);
                                                var commandBuilder = new SqlCommandBuilder(dataAdapter);
                                                var ds = new DataSet();
                                                dataAdapter.Fill(ds);
                                                conn.Close();
                                                dgvViewClient.ReadOnly = true;
                                                dgvViewClient.DataSource = ds.Tables[0];

                                                MessageBox.Show("Updated Successfully!", "Action Completed Successfully!");
                                            }
                                            else
                                            {
                                                MessageBox.Show("Package Type cannot be blank");
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show("Type cannot be blank!");
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Status cannot be blank!");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Address cannot be blank!");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Contact Number cannot be blank!");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Last Name cannot be blank!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("First Name cannot be blank!");
                    }
                }
                else
                {
                    MessageBox.Show("Client ID cannot be blank!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                string clientID = txtClientID.Text;
                string firstName = txtName.Text;
                string lastName = txtLName.Text;
                string contactNumber = txtContact.Text;
                string address = txtAddress.Text;
                string status = cmbStatus.Text;
                string type = cmbType.Text;
                string packageType = cmbPacakge.Text;
                string notes = rtbNotes.Text;

                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";

                if (clientID != "")
                {
                    if (firstName != "")
                    {
                        if (lastName != "")
                        {
                            if (contactNumber != "")
                            {
                                if (address != "")
                                {
                                    if (status != "")
                                    {
                                        if (type != "")
                                        {
                                            if (packageType != "")
                                            {
                                                conn.Open();
                                                SqlCommand cmdDelete = new SqlCommand("DELETE FROM dbo.CLIENTS WHERE CLIENT_ID = '" + clientID + "'", conn);
                                                int updatedRows = cmdDelete.ExecuteNonQuery();

                                                var slcquery = "SELECT * FROM dbo.CLIENTS";
                                                var dataAdapter = new SqlDataAdapter(slcquery, conn);
                                                var commandBuilder = new SqlCommandBuilder(dataAdapter);
                                                var ds = new DataSet();
                                                dataAdapter.Fill(ds);
                                                conn.Close();
                                                dgvViewClient.ReadOnly = true;
                                                dgvViewClient.DataSource = ds.Tables[0];

                                                MessageBox.Show("Updated Successfully!", "Action Completed Successfully!");
                                            }
                                            else
                                            {
                                                MessageBox.Show("Package Type cannot be blank");
                                            }
                                        }
                                        else
                                        {
                                            MessageBox.Show("Type cannot be blank!");
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Status cannot be blank!");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Address cannot be blank!");
                                }
                            }
                            else
                            {
                                MessageBox.Show("Contact Number cannot be blank!");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Last Name cannot be blank!");
                        }
                    }
                    else
                    {
                        MessageBox.Show("First Name cannot be blank!");
                    }
                }
                else
                {
                    MessageBox.Show("Client ID cannot be blank!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string clientNum = txtSearch.Text;
            if (clientNum != "")
            {
                var slcquery = "SELECT * FROM dbo.CLIENTS WHERE CLIENT_ID LIKE '%" + clientNum + "%'";
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";
                conn.Open();
                var dataAdapter = new SqlDataAdapter(slcquery, conn);
                var commandBuilder = new SqlCommandBuilder(dataAdapter);
                var ds = new DataSet();
                dataAdapter.Fill(ds);
                conn.Close();
                dgvViewClient.ReadOnly = true;
                dgvViewClient.DataSource = ds.Tables[0];
            }
            else
            {
                var slcquery = "SELECT * FROM dbo.CLIENTS";
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";
                conn.Open();
                var dataAdapter = new SqlDataAdapter(slcquery, conn);
                var commandBuilder = new SqlCommandBuilder(dataAdapter);
                var ds = new DataSet();
                dataAdapter.Fill(ds);
                conn.Close();
                dgvViewClient.ReadOnly = true;
                dgvViewClient.DataSource = ds.Tables[0];
            }
        }
    }
}
