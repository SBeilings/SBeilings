﻿
namespace GroupB_Project.PresentatioN_Layer
{
    partial class frmServiceMaintenanceAgentDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbxServiceMaintenance = new System.Windows.Forms.GroupBox();
            this.btnIncidents = new System.Windows.Forms.Button();
            this.lblClients = new System.Windows.Forms.Button();
            this.btnContracts = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.gbxServiceMaintenance.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbxServiceMaintenance
            // 
            this.gbxServiceMaintenance.Controls.Add(this.btnContracts);
            this.gbxServiceMaintenance.Controls.Add(this.lblClients);
            this.gbxServiceMaintenance.Controls.Add(this.btnIncidents);
            this.gbxServiceMaintenance.Location = new System.Drawing.Point(205, 12);
            this.gbxServiceMaintenance.Name = "gbxServiceMaintenance";
            this.gbxServiceMaintenance.Size = new System.Drawing.Size(806, 499);
            this.gbxServiceMaintenance.TabIndex = 0;
            this.gbxServiceMaintenance.TabStop = false;
            this.gbxServiceMaintenance.Text = "Service Dashboard";
            // 
            // btnIncidents
            // 
            this.btnIncidents.Location = new System.Drawing.Point(255, 40);
            this.btnIncidents.Name = "btnIncidents";
            this.btnIncidents.Size = new System.Drawing.Size(307, 77);
            this.btnIncidents.TabIndex = 0;
            this.btnIncidents.Text = "View and Update Incidents";
            this.btnIncidents.UseVisualStyleBackColor = true;
            this.btnIncidents.Click += new System.EventHandler(this.btnIncidents_Click);
            // 
            // lblClients
            // 
            this.lblClients.Location = new System.Drawing.Point(255, 210);
            this.lblClients.Name = "lblClients";
            this.lblClients.Size = new System.Drawing.Size(307, 77);
            this.lblClients.TabIndex = 1;
            this.lblClients.Text = "View and Update Clients";
            this.lblClients.UseVisualStyleBackColor = true;
            this.lblClients.Click += new System.EventHandler(this.lblClients_Click);
            // 
            // btnContracts
            // 
            this.btnContracts.Location = new System.Drawing.Point(255, 375);
            this.btnContracts.Name = "btnContracts";
            this.btnContracts.Size = new System.Drawing.Size(307, 77);
            this.btnContracts.TabIndex = 2;
            this.btnContracts.Text = "View and Update Contracts";
            this.btnContracts.UseVisualStyleBackColor = true;
            this.btnContracts.Click += new System.EventHandler(this.btnContracts_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(1056, 476);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(130, 52);
            this.btnLogout.TabIndex = 1;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // frmServiceMaintenanceAgentDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1232, 575);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.gbxServiceMaintenance);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmServiceMaintenanceAgentDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Service Maintenance - Agent Dashboard";
            this.gbxServiceMaintenance.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbxServiceMaintenance;
        private System.Windows.Forms.Button btnContracts;
        private System.Windows.Forms.Button lblClients;
        private System.Windows.Forms.Button btnIncidents;
        private System.Windows.Forms.Button btnLogout;
    }
}