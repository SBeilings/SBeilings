﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using GroupB_Project.PresentatioN_Layer;

namespace GroupB_Project
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        public string getUserName()
        {
           string Login_Name = txtUsername.Text;
            return Login_Name;
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                getUserName();
                string Name = txtUsername.Text;
                string Pass = txtPassword.Text;
                string returned_Username = "No Username Found!";
                string returned_Password = "No Passwords Found!";

                if (Name != "" && Pass != "")
                {
                    SqlConnection conn = new SqlConnection();
                    conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";
                    conn.Open();

                    SqlCommand cmdSelectUsername = new SqlCommand("SELECT OPERATOR_CODE From dbo.USERS WHERE OPERATOR_CODE = '" + Name + "'", conn);
                    SqlDataReader drUsername = cmdSelectUsername.ExecuteReader();

                    while (drUsername.Read())
                    {
                        returned_Username = drUsername.GetString(0);
                    }

                    drUsername.Close();


                    SqlCommand cmdSelectPassword = new SqlCommand("SELECT PASSWORD From dbo.USERS WHERE PASSWORD = '" + Pass + "'", conn);
                    SqlDataReader drPassword = cmdSelectPassword.ExecuteReader();

                    while (drPassword.Read())
                    {
                        returned_Password = drPassword.GetString(0);
                    }

                    drPassword.Close();

                    conn.Close();

                    if (Name == returned_Username && Pass == returned_Password)
                    {
                        this.Hide();
                        frmServiceMaintenanceAgentDashboard curr_menu = new frmServiceMaintenanceAgentDashboard();
                        curr_menu.Show();
                    }
                    else
                    {
                        Console.WriteLine(returned_Password + " " + returned_Username );
                        MessageBox.Show("Please Re-Enter Your Password or Operator Code Again!","Something Went Wrong");
                    }
                }
                else
                {
                    MessageBox.Show("Sorry, No blanks allowed","Something Went Wrong");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {
            string msgtext = "1234";
            if (MessageBox.Show(msgtext, "Press OK to copy Password", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
            { Clipboard.SetText(msgtext); }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string operatorCode = txtoperatorCode.Text;

                if (operatorCode != "")
                {
                    SqlConnection conn = new SqlConnection();
                    conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";
                    conn.Open();

                    SqlCommand cmdSelectPassword = new SqlCommand("SELECT PASSWORD From dbo.USERS WHERE OPERATOR_CODE = '" + operatorCode + "'", conn);
                    SqlDataReader drPassword = cmdSelectPassword.ExecuteReader();
                    
                    string returned_Password = "NO PASSWORD FOUND!";

                    while (drPassword.Read())
                    {
                        returned_Password = drPassword.GetString(0);
                    }

                    drPassword.Close();

                    conn.Close();

                    txtretrievedPassword.Text = returned_Password;
                }
                else
                {
                    MessageBox.Show("No Operator Code entered");
                }
            }
            catch (Exception ex)
            { 
                MessageBox.Show(ex.Message);
            }
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
