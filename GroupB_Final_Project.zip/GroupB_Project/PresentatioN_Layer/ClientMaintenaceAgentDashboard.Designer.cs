﻿
namespace GroupB_Project.PresentatioN_Layer
{
    partial class ClientMaintenaceAgentDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbxViewClients = new System.Windows.Forms.GroupBox();
            this.lblClientID = new System.Windows.Forms.Label();
            this.btnViewAll = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.dgvViewClient = new System.Windows.Forms.DataGridView();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnCreateNewClient = new System.Windows.Forms.Button();
            this.gbxUpdateClient = new System.Windows.Forms.GroupBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.linkViewID = new System.Windows.Forms.LinkLabel();
            this.cmbPacakge = new System.Windows.Forms.ComboBox();
            this.cmbType = new System.Windows.Forms.ComboBox();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.txtClientID = new System.Windows.Forms.TextBox();
            this.rtbNotes = new System.Windows.Forms.RichTextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.lblLname = new System.Windows.Forms.Label();
            this.lblContactNo = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblType = new System.Windows.Forms.Label();
            this.lblPackageType = new System.Windows.Forms.Label();
            this.lblNotes = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnLogout = new System.Windows.Forms.Button();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.gbxViewClients.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvViewClient)).BeginInit();
            this.gbxUpdateClient.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbxViewClients
            // 
            this.gbxViewClients.Controls.Add(this.lblClientID);
            this.gbxViewClients.Controls.Add(this.btnViewAll);
            this.gbxViewClients.Controls.Add(this.btnSearch);
            this.gbxViewClients.Controls.Add(this.dgvViewClient);
            this.gbxViewClients.Controls.Add(this.txtSearch);
            this.gbxViewClients.Location = new System.Drawing.Point(22, 25);
            this.gbxViewClients.Name = "gbxViewClients";
            this.gbxViewClients.Size = new System.Drawing.Size(871, 540);
            this.gbxViewClients.TabIndex = 0;
            this.gbxViewClients.TabStop = false;
            this.gbxViewClients.Text = "View and Create Client";
            this.gbxViewClients.Enter += new System.EventHandler(this.gbxViewClients_Enter);
            // 
            // lblClientID
            // 
            this.lblClientID.AutoSize = true;
            this.lblClientID.Location = new System.Drawing.Point(466, 20);
            this.lblClientID.Name = "lblClientID";
            this.lblClientID.Size = new System.Drawing.Size(47, 13);
            this.lblClientID.TabIndex = 18;
            this.lblClientID.Text = "Client ID";
            // 
            // btnViewAll
            // 
            this.btnViewAll.Location = new System.Drawing.Point(365, 469);
            this.btnViewAll.Margin = new System.Windows.Forms.Padding(2);
            this.btnViewAll.Name = "btnViewAll";
            this.btnViewAll.Size = new System.Drawing.Size(65, 19);
            this.btnViewAll.TabIndex = 16;
            this.btnViewAll.Text = "Refresh";
            this.btnViewAll.UseVisualStyleBackColor = true;
            this.btnViewAll.Click += new System.EventHandler(this.btnViewAll_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(646, 17);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(2);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(56, 19);
            this.btnSearch.TabIndex = 15;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // dgvViewClient
            // 
            this.dgvViewClient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvViewClient.Location = new System.Drawing.Point(26, 49);
            this.dgvViewClient.Margin = new System.Windows.Forms.Padding(2);
            this.dgvViewClient.Name = "dgvViewClient";
            this.dgvViewClient.RowHeadersWidth = 51;
            this.dgvViewClient.RowTemplate.Height = 24;
            this.dgvViewClient.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvViewClient.Size = new System.Drawing.Size(742, 400);
            this.dgvViewClient.TabIndex = 14;
            this.dgvViewClient.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvViewClient_CellContentClick);
            this.dgvViewClient.SelectionChanged += new System.EventHandler(this.dgvViewClient_SelectionChanged);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(538, 17);
            this.txtSearch.Margin = new System.Windows.Forms.Padding(2);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(90, 20);
            this.txtSearch.TabIndex = 13;
            // 
            // btnCreateNewClient
            // 
            this.btnCreateNewClient.Location = new System.Drawing.Point(285, 593);
            this.btnCreateNewClient.Margin = new System.Windows.Forms.Padding(2);
            this.btnCreateNewClient.Name = "btnCreateNewClient";
            this.btnCreateNewClient.Size = new System.Drawing.Size(250, 70);
            this.btnCreateNewClient.TabIndex = 17;
            this.btnCreateNewClient.Text = "Create New Client";
            this.btnCreateNewClient.UseVisualStyleBackColor = true;
            this.btnCreateNewClient.Click += new System.EventHandler(this.btnCreateNewClient_Click);
            // 
            // gbxUpdateClient
            // 
            this.gbxUpdateClient.Controls.Add(this.btnDelete);
            this.gbxUpdateClient.Controls.Add(this.linkViewID);
            this.gbxUpdateClient.Controls.Add(this.cmbPacakge);
            this.gbxUpdateClient.Controls.Add(this.cmbType);
            this.gbxUpdateClient.Controls.Add(this.cmbStatus);
            this.gbxUpdateClient.Controls.Add(this.txtAddress);
            this.gbxUpdateClient.Controls.Add(this.txtContact);
            this.gbxUpdateClient.Controls.Add(this.txtName);
            this.gbxUpdateClient.Controls.Add(this.txtLName);
            this.gbxUpdateClient.Controls.Add(this.txtClientID);
            this.gbxUpdateClient.Controls.Add(this.rtbNotes);
            this.gbxUpdateClient.Controls.Add(this.lblName);
            this.gbxUpdateClient.Controls.Add(this.lblLname);
            this.gbxUpdateClient.Controls.Add(this.lblContactNo);
            this.gbxUpdateClient.Controls.Add(this.lblAddress);
            this.gbxUpdateClient.Controls.Add(this.lblStatus);
            this.gbxUpdateClient.Controls.Add(this.lblType);
            this.gbxUpdateClient.Controls.Add(this.lblPackageType);
            this.gbxUpdateClient.Controls.Add(this.lblNotes);
            this.gbxUpdateClient.Controls.Add(this.btnSave);
            this.gbxUpdateClient.Controls.Add(this.label1);
            this.gbxUpdateClient.Location = new System.Drawing.Point(917, 25);
            this.gbxUpdateClient.Name = "gbxUpdateClient";
            this.gbxUpdateClient.Size = new System.Drawing.Size(448, 524);
            this.gbxUpdateClient.TabIndex = 1;
            this.gbxUpdateClient.TabStop = false;
            this.gbxUpdateClient.Text = "Update Client";
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(144, 471);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(78, 24);
            this.btnDelete.TabIndex = 69;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // linkViewID
            // 
            this.linkViewID.AutoSize = true;
            this.linkViewID.Location = new System.Drawing.Point(593, 24);
            this.linkViewID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.linkViewID.Name = "linkViewID";
            this.linkViewID.Size = new System.Drawing.Size(97, 13);
            this.linkViewID.TabIndex = 68;
            this.linkViewID.TabStop = true;
            this.linkViewID.Text = "View Client HIistory";
            // 
            // cmbPacakge
            // 
            this.cmbPacakge.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPacakge.FormattingEnabled = true;
            this.cmbPacakge.Location = new System.Drawing.Point(144, 316);
            this.cmbPacakge.Margin = new System.Windows.Forms.Padding(2);
            this.cmbPacakge.Name = "cmbPacakge";
            this.cmbPacakge.Size = new System.Drawing.Size(230, 21);
            this.cmbPacakge.TabIndex = 67;
            // 
            // cmbType
            // 
            this.cmbType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbType.FormattingEnabled = true;
            this.cmbType.Location = new System.Drawing.Point(144, 275);
            this.cmbType.Margin = new System.Windows.Forms.Padding(2);
            this.cmbType.Name = "cmbType";
            this.cmbType.Size = new System.Drawing.Size(230, 21);
            this.cmbType.TabIndex = 66;
            // 
            // cmbStatus
            // 
            this.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Location = new System.Drawing.Point(144, 231);
            this.cmbStatus.Margin = new System.Windows.Forms.Padding(2);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(230, 21);
            this.cmbStatus.TabIndex = 65;
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(144, 187);
            this.txtAddress.Margin = new System.Windows.Forms.Padding(2);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(230, 20);
            this.txtAddress.TabIndex = 64;
            // 
            // txtContact
            // 
            this.txtContact.Location = new System.Drawing.Point(144, 146);
            this.txtContact.Margin = new System.Windows.Forms.Padding(2);
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(230, 20);
            this.txtContact.TabIndex = 63;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(144, 65);
            this.txtName.Margin = new System.Windows.Forms.Padding(2);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(230, 20);
            this.txtName.TabIndex = 62;
            // 
            // txtLName
            // 
            this.txtLName.Location = new System.Drawing.Point(144, 106);
            this.txtLName.Margin = new System.Windows.Forms.Padding(2);
            this.txtLName.Name = "txtLName";
            this.txtLName.Size = new System.Drawing.Size(230, 20);
            this.txtLName.TabIndex = 61;
            // 
            // txtClientID
            // 
            this.txtClientID.Location = new System.Drawing.Point(144, 21);
            this.txtClientID.Margin = new System.Windows.Forms.Padding(2);
            this.txtClientID.Name = "txtClientID";
            this.txtClientID.ReadOnly = true;
            this.txtClientID.Size = new System.Drawing.Size(230, 20);
            this.txtClientID.TabIndex = 60;
            // 
            // rtbNotes
            // 
            this.rtbNotes.Location = new System.Drawing.Point(144, 363);
            this.rtbNotes.Margin = new System.Windows.Forms.Padding(2);
            this.rtbNotes.Name = "rtbNotes";
            this.rtbNotes.Size = new System.Drawing.Size(230, 86);
            this.rtbNotes.TabIndex = 59;
            this.rtbNotes.Text = "";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(32, 68);
            this.lblName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(60, 13);
            this.lblName.TabIndex = 58;
            this.lblName.Text = "First Name:";
            // 
            // lblLname
            // 
            this.lblLname.AutoSize = true;
            this.lblLname.Location = new System.Drawing.Point(32, 109);
            this.lblLname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblLname.Name = "lblLname";
            this.lblLname.Size = new System.Drawing.Size(61, 13);
            this.lblLname.TabIndex = 57;
            this.lblLname.Text = "Last Name:";
            // 
            // lblContactNo
            // 
            this.lblContactNo.AutoSize = true;
            this.lblContactNo.Location = new System.Drawing.Point(32, 149);
            this.lblContactNo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblContactNo.Name = "lblContactNo";
            this.lblContactNo.Size = new System.Drawing.Size(87, 13);
            this.lblContactNo.TabIndex = 56;
            this.lblContactNo.Text = "Contact Number:";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(32, 190);
            this.lblAddress.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(48, 13);
            this.lblAddress.TabIndex = 55;
            this.lblAddress.Text = "Address:";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(32, 235);
            this.lblStatus.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(40, 13);
            this.lblStatus.TabIndex = 54;
            this.lblStatus.Text = "Status:";
            // 
            // lblType
            // 
            this.lblType.AutoSize = true;
            this.lblType.Location = new System.Drawing.Point(32, 279);
            this.lblType.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(34, 13);
            this.lblType.TabIndex = 53;
            this.lblType.Text = "Type:";
            // 
            // lblPackageType
            // 
            this.lblPackageType.AutoSize = true;
            this.lblPackageType.Location = new System.Drawing.Point(32, 320);
            this.lblPackageType.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPackageType.Name = "lblPackageType";
            this.lblPackageType.Size = new System.Drawing.Size(80, 13);
            this.lblPackageType.TabIndex = 52;
            this.lblPackageType.Text = "Package Type:";
            // 
            // lblNotes
            // 
            this.lblNotes.AutoSize = true;
            this.lblNotes.Location = new System.Drawing.Point(32, 362);
            this.lblNotes.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNotes.Name = "lblNotes";
            this.lblNotes.Size = new System.Drawing.Size(38, 13);
            this.lblNotes.TabIndex = 51;
            this.lblNotes.Text = "Notes:";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(294, 469);
            this.btnSave.Margin = new System.Windows.Forms.Padding(2);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(80, 26);
            this.btnSave.TabIndex = 49;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 27);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 48;
            this.label1.Text = "Client ID:";
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(1142, 632);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(2);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(149, 45);
            this.btnLogout.TabIndex = 50;
            this.btnLogout.Text = "Home";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // ClientMaintenaceAgentDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1377, 715);
            this.Controls.Add(this.gbxUpdateClient);
            this.Controls.Add(this.btnCreateNewClient);
            this.Controls.Add(this.gbxViewClients);
            this.Controls.Add(this.btnLogout);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ClientMaintenaceAgentDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Client Maintenance - Agent Dashboard";
            this.Load += new System.EventHandler(this.ClientMaintenaceAgentDashboard_Load);
            this.gbxViewClients.ResumeLayout(false);
            this.gbxViewClients.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvViewClient)).EndInit();
            this.gbxUpdateClient.ResumeLayout(false);
            this.gbxUpdateClient.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbxViewClients;
        private System.Windows.Forms.Label lblClientID;
        private System.Windows.Forms.Button btnCreateNewClient;
        private System.Windows.Forms.Button btnViewAll;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DataGridView dgvViewClient;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.GroupBox gbxUpdateClient;
        private System.Windows.Forms.LinkLabel linkViewID;
        private System.Windows.Forms.ComboBox cmbPacakge;
        private System.Windows.Forms.ComboBox cmbType;
        private System.Windows.Forms.ComboBox cmbStatus;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtContact;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.TextBox txtClientID;
        private System.Windows.Forms.RichTextBox rtbNotes;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblLname;
        private System.Windows.Forms.Label lblContactNo;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.Label lblPackageType;
        private System.Windows.Forms.Label lblNotes;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLogout;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button btnDelete;
    }
}