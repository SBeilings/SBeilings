﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GroupB_Project.PresentatioN_Layer
{
    public partial class ClientIDSearch : Form
    {
        public ClientIDSearch()
        {
            InitializeComponent();
        }

        private void ClientIDSearch_Load(object sender, EventArgs e)
        {

            var slcquery = "SELECT CLIENT_ID,FNAME,SNAME FROM dbo.CLIENTS";
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";
            conn.Open();
            var dataAdapter = new SqlDataAdapter(slcquery, conn);
            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            conn.Close();
            dgvViewClient.ReadOnly = true;
            dgvViewClient.DataSource = ds.Tables[0];
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string clientNum = txtSearch.Text;
            if (clientNum != "")
            {
                var slcquery = "SELECT CLIENT_ID,FNAME,SNAME FROM dbo.CLIENTS WHERE CLIENT_ID LIKE '%" + clientNum + "%'";
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";
                conn.Open();
                var dataAdapter = new SqlDataAdapter(slcquery, conn);
                var commandBuilder = new SqlCommandBuilder(dataAdapter);
                var ds = new DataSet();
                dataAdapter.Fill(ds);
                conn.Close();
                dgvViewClient.ReadOnly = true;
                dgvViewClient.DataSource = ds.Tables[0];
            }
            else
            {
                var slcquery = "SELECT CLIENT_ID,FNAME,SNAME FROM dbo.CLIENTS";
                SqlConnection conn = new SqlConnection();
                conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";
                conn.Open();
                var dataAdapter = new SqlDataAdapter(slcquery, conn);
                var commandBuilder = new SqlCommandBuilder(dataAdapter);
                var ds = new DataSet();
                dataAdapter.Fill(ds);
                conn.Close();
                dgvViewClient.ReadOnly = true;
                dgvViewClient.DataSource = ds.Tables[0];
            }
        }

        private void btnViewAll_Click(object sender, EventArgs e)
        {
            var slcquery = "SELECT CLIENT_ID FROM dbo.CLIENTS";
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = @"Server=DESKTOP-DDSU092\SQLEXPRESS; Initial Catalog = PremierServiceSolutions_DB1 ; Integrated Security = SSPI";
            conn.Open();
            var dataAdapter = new SqlDataAdapter(slcquery, conn);
            var commandBuilder = new SqlCommandBuilder(dataAdapter);
            var ds = new DataSet();
            dataAdapter.Fill(ds);
            conn.Close();
            dgvViewClient.ReadOnly = true;
            dgvViewClient.DataSource = ds.Tables[0];
        }
    }
}
