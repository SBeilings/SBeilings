﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using GroupB_Project.Business_Layer;

namespace GroupB_Project.Data_Layer
{
    class DataHandler
    {
        // Set connection string
        string connect = "Data Source=.;Initial Catalog=Group2_Schema; Integrated Security= SSPI";
        SqlConnection conn;  // Declare  SqlConnection object
        SqlCommand command; // 
        SqlDataReader rdr;
        Client allclients = new Client();

        // Inserting a client and creating a new client  
        public void createClient(int clientid, string first_name, string last_name, string contact, string address, string status, string clientType, string package_type, string clientNotes)
        {
            string insertClient = @"Insert into tblclient (Client_ID,name, l_name , contact_No,address, Client_Type, Package_Type,Client_Note)
                 Values('" + clientid + "','" + first_name + "','" + last_name + "','" + contact + "','" + address + "','" + status + "','" + clientType + "','" + clientNotes + "' )";
            conn = new SqlConnection(connect);
            conn.Open();
            command = new SqlCommand(insertClient, conn);
            command.ExecuteNonQuery();
            MessageBox.Show(" Client Record Saved in the database!! ");
            conn.Close();
        }

        //code for searching for a client using their ID

      

    }
}
