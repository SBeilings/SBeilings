﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupB_Project.Business_Layer
{
    class Client
    {

        private string first_name, last_name, contact, address, status, clientType, package_type, clientNotes;
        private int clientid;
        //client empty constructor
        public Client()
        {
        }
        // Client constructor
        public Client(int clientid, string first_name, string last_name, string contact, string address, string status, string clientType, string package_type, string clientNotes)
        {
            this.clientid = clientid;
            this.first_name = first_name;
            this.last_name = last_name;
            this.contact = contact;
            this.address = address;
            this.status = status;
            this.clientType = clientType;
            this.package_type = package_type;
            this.clientNotes = clientNotes;

        }
        //client properties
        public int Clientid { get => clientid; set => clientid = value; }
        public string First_name { get => first_name; set => first_name = value; }
        public string Last_name { get => last_name; set => last_name = value; }
        public string Contact { get => contact; set => contact = value; }
        public string Address { get => address; set => address = value; }
        public string Status { get => status; set => status = value; }
        public string ClientType { get => clientType; set => clientType = value; }
        public string Package_type { get => package_type; set => package_type = value; }
        public string ClientNotes { get => clientNotes; set => clientNotes = value; }



    }
}
