USE [PremierServiceSolutions_DB1]
GO

/****** Object:  Table [dbo].[INCIDENTS]    Script Date: 6/10/2022 9:11:45 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[INCIDENTS](
	[INCIDENT_NUM] [varchar](50) NOT NULL,
	[INCIDENT_TYPE] [varchar](50) NOT NULL,
	[CLIENT_ID] [varchar](50) NOT NULL,
	[WORK_REQ_NUMBER] [varchar](50) NOT NULL,
	[STATUS] [varchar](50) NOT NULL,
	[TECHNICIAN] [varchar](50) NOT NULL
) ON [PRIMARY]
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'All Incidents are logged in this Table' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'INCIDENTS'
GO

