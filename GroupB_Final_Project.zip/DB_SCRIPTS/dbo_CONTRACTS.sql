USE [PremierServiceSolutions_DB1]
GO

/****** Object:  Table [dbo].[CONTRACTS]    Script Date: 6/10/2022 9:11:30 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CONTRACTS](
	[PACKAGE_ID] [varchar](50) NOT NULL,
	[NAME] [varchar](50) NOT NULL,
	[SERVICE_LEVEL] [varchar](50) NOT NULL,
	[CONTRACT_TYPE] [varchar](50) NOT NULL,
	[SERVICE_TYPE] [varchar](50) NOT NULL,
	[START_DATE] [varchar](50) NOT NULL,
	[END_DATE] [varchar](50) NOT NULL
) ON [PRIMARY]
GO

