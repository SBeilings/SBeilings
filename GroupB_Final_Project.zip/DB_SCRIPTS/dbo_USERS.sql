USE [PremierServiceSolutions_DB1]
GO

/****** Object:  Table [dbo].[USERS]    Script Date: 6/10/2022 9:11:55 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[USERS](
	[OPERATOR_CODE] [varchar](50) NULL,
	[PASSWORD] [varchar](50) NULL,
	[OPERATOR_TYPE] [varchar](50) NULL
) ON [PRIMARY]
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'For Application Login and Security' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'USERS'
GO

